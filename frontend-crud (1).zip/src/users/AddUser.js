import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function AddUser() {
  let navigate = useNavigate();

  const [user, setUser] = useState({
    dni: "",
    username: "",
    password: "",
    email: "",
    apellidos: "",
    direccion: "",
  });

  const { dni, username,password, email, apellidos,direccion } = user;

  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8080/usuarios/guardar", user);
    navigate("/");
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4">Registrar Usuario</h2>

          <form onSubmit={(e) => onSubmit(e)}>
            <div className="mb-3">
              <label htmlFor="Dni" className="form-label">
                DNI
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Ingrese dni"
                name="dni"
                value={dni}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Username" className="form-label">
                Username
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Ingrese username"
                name="username"
                value={username}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
                Correo
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Ingrese correo"
                name="email"
                value={email}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Username" className="form-label">
                Contraseña
              </label>
              <input
                type={"password"}
                className="form-control"
                placeholder="Ingrese password"
                name="password"
                value={password}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
                Apellido
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Ingrese apellidos"
                name="apellidos"
                value={apellidos}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
                Direccion
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Ingrese direccion"
                name="direccion"
                value={direccion}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <button type="submit" className="btn btn-outline-primary">
              Guardar
            </button>
            <Link className="btn btn-outline-danger mx-2" to="/">
              Cancelar
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}
